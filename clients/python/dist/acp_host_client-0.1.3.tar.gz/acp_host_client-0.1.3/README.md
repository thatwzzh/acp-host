# acp-host-client（Python）

`acp-host` 的薄客户端：起进程、按行 JSON 收事件。**不需要你装 Rust**——首次使用会自动下载对应平台的二进制。

```bash
pip install acp-host-client
```

```python
from acp_host import AcpHost

host = AcpHost()
for piece in host.ask("你好", agent="workbuddy"):
    print(piece, end="")
host.close()
```

二进制查找顺序：`ACP_HOST_BIN` → PATH 上的 `acp-host` → `~/.cache/acp-host/<版本>/` → 现下。

协议与 agent 配置见 https://github.com/thatwzzh/acp-host
